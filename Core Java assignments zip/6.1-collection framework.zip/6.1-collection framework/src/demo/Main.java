package demo;

import java.util.ArrayList;

class Main {
	public static void main (String[] args) {
		ArrayList<Integer> list = new ArrayList<>();

	
	list.add(1);
	list.add(2);
	list.add(3);
	list.add(4);
		
	
	if(list.indexOf(2)>=0)
		System.out.println("Tom exists in the List");
		
	else
		System.out.println("Tom does not exist in the List");
		
	if(list.indexOf(8)>=0)
		System.out.println("Jerry exists in the List");
		
	else
		System.out.println("Jerry does not exist in the List");
		
	}
}

package demo;

class Client
{
    // Function to check if strings 'X' and 'Y' are interleaving of string 'S' or not
    public static boolean isShuffling(String first, String second, String third)
    {
        // return true if the end of all strings is reached
        if (first.length() == 0 && second.length() == 0 && third.length() == 0) {
            return true;
        }
 
        // return false if the end of string 'S' is reached,
        // but string 'X' or 'Y' is not empty
 
        if (third.length() == 0) {
            return false;
        }
 
        // if string 'X' is not empty and its first character matches with the
        // first character of 'S', recur for the remaining substring
 
        if (first.length() != 0 && third.charAt(0) == first.charAt(0)) {
            return isShuffling(first.substring(1), second, third.substring(1));
        }
 
        // if string 'Y' is not empty and its first character matches with the
        // first character of 'S', recur for the remaining substring
 
        if (second.length() != 0 && third.charAt(0) == second.charAt(0)) {
            return isShuffling(first, second.substring(1), third.substring(1));
        }
 
        return false;
    }
 
    public static void main(String[] args)
    {
        String first = "pqr";
        String second = "lmno";
        String third = "plmrqon";
 
        if (isShuffling(first, second, third)) {
            System.out.print("true: given string is a valid shuffle of first and second string");
        }
        else {
            System.out.print("false: third string is not valid shuffle of first and second string");
        }
    }
}
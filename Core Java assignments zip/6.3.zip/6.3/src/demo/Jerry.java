package demo;

import java.util.Vector;

public class Jerry {
	public static void main(String[] args) {
		Vector<Main> v = addInput();
		display(v);
		}

	private static Vector<Main> addInput() {
		return null;
	}

	private static void display(Vector<Main> v) {
		
	}

	public static void main1(String[] args) {
		Main e1=new Main (101,"john", "blore");
		Main e2=new Main (102,"tom", "mlore");
		Main e3=new Main (103,"oggy", "mandya");
		Vector<Main> v=new Vector<Main>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
	}
	public static void main2(String[] args) {
		for(Main e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}
}
